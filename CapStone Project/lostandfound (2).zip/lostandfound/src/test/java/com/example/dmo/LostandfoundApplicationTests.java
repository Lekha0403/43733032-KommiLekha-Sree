package com.example.dmo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostandfoundApplicationTests {

	@Test
	void contextLoads() {
	}

}
