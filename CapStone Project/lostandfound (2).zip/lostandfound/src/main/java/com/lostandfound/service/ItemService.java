package com.lostandfound.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lostandfound.model.Item;
import com.lostandfound.model.ItemStatus;
import com.lostandfound.repository.ItemRepository;

@Service
public class ItemService {

    private final ItemRepository repository;

    public ItemService(ItemRepository repository) {
        this.repository = repository;
    }

    // Save new or edited item
    public Item saveItem(Item item) {
        if (item.getStatus() == null) {
            item.setStatus(ItemStatus.LOST);
        }
        return repository.save(item);
    }

    // Get all items
    public List<Item> getAllItems() {
        return repository.findAll();
    }

    // Get item by ID (for Edit)
    public Item getItemById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item not found"));
    }

 // ✅ MARK FOUND
    public Item markAsFound(Long id) {
        Item item = repository.findById(id).orElse(null);
        if (item != null) {
            item.setStatus(ItemStatus.FOUND);
            return repository.save(item);
        }
        return null;
    }

    // Delete item
    public void deleteItem(Long id) {
        repository.deleteById(id);
    }

    // Search items
    public List<Item> searchItems(String keyword) {
        return repository.searchItems(keyword);
    }
}
