package com.lostandfound.controller;

import com.lostandfound.model.Item;
import com.lostandfound.service.ItemService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller
@RequestMapping("/items")
public class ItemPageController {

    private final ItemService service;

    public ItemPageController(ItemService service) {
        this.service = service;
    }

    // Show items page
    @GetMapping
    public String viewItems(
            @RequestParam(required = false) String keyword,
            Model model) {

        if (keyword != null && !keyword.isEmpty()) {
            model.addAttribute("items", service.searchItems(keyword));
        } else {
            model.addAttribute("items", service.getAllItems());
        }

        model.addAttribute("keyword", keyword);
        return "items";
    }


    // Show add item form
    @GetMapping("/add")
    public String showAddItemForm(Model model) {
        model.addAttribute("item", new Item());
        return "add-item";
    }

    // ✅ SAVE ITEM (FIXED)
    @PostMapping("/save")
    public String saveItem(
            @ModelAttribute Item item,
            @RequestParam("image") MultipartFile imageFile
    ) {

        // 🔒 PROTECTION: Prevent duplicate save
        if (item.getId() != null) {
            return "redirect:/items";
        }

        try {
            if (imageFile != null && !imageFile.isEmpty()) {

                String uploadDir = "uploads/";
                Files.createDirectories(Paths.get(uploadDir));

                String fileName = System.currentTimeMillis() + "_" + imageFile.getOriginalFilename();
                Path filePath = Paths.get(uploadDir + fileName);
                Files.write(filePath, imageFile.getBytes());

                // Save image name in DB
                item.setImageName(fileName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        service.saveItem(item);
        return "redirect:/items";
    }

    // Mark item as FOUND
    @PostMapping("/mark-found/{id}")
    public String markAsFound(@PathVariable Long id) {
        service.markAsFound(id);
        return "redirect:/items";
    }

    // Delete item
    @PostMapping("/delete/{id}")
    public String deleteItem(@PathVariable Long id) {
        service.deleteItem(id);
        return "redirect:/items";
    }
    @GetMapping("/search")
    public String searchItems(@RequestParam("keyword") String keyword, Model model) {
        model.addAttribute("items", service.searchItems(keyword));
        return "items";
    }
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Item item = service.getItemById(id);
        model.addAttribute("item", item);
        return "add-item";
    }


}
