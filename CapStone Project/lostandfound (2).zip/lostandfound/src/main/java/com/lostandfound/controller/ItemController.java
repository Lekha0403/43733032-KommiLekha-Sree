package com.lostandfound.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.lostandfound.model.Item;
import com.lostandfound.service.ItemService;

@RestController
@RequestMapping("/api/items")
public class ItemController {

    private final ItemService service;

    public ItemController(ItemService service) {
        this.service = service;
    }

    // ✅ POST: Add item
    @PostMapping
    public Item addItem(@RequestBody Item item) {
        return service.saveItem(item);
    }

    // ✅ GET: View all items
    @GetMapping
    public List<Item> getItems() {
        return service.getAllItems();
    }

    // ✅ PUT: Mark item as FOUND
    @PutMapping("/{id}/found")
    public Item markAsFound(@PathVariable Long id) {
        return service.markAsFound(id);
    }

    // ✅ DELETE: Delete item
    @DeleteMapping("/{id}")
    public void deleteItem(@PathVariable Long id) {
        service.deleteItem(id);
    }
}
