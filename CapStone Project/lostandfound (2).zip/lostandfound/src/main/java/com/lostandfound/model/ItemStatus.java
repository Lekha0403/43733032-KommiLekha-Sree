package com.lostandfound.model;

public enum ItemStatus {
    LOST,
    FOUND
}
