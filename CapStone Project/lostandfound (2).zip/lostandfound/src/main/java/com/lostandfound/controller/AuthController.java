package com.lostandfound.controller;

import com.lostandfound.model.User;
import com.lostandfound.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    private final UserRepository userRepository;

    public AuthController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // LOGIN PAGE
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // LOGIN PROCESS
    @PostMapping("/login")
    public String loginUser(
            @RequestParam String email,
            @RequestParam String password,
            HttpSession session,
            Model model) {

        User user = userRepository.findByEmail(email);

        if (user != null && user.getPassword().equals(password)) {

            // ✅ SAVE USER INFO IN SESSION
            session.setAttribute("loggedUser", user.getUsername());

            return "redirect:/";
        }

        model.addAttribute("error", "Invalid email or password");
        return "login";
    }

    // REGISTER PAGE
    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    // REGISTER PROCESS
    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user) {
        userRepository.save(user);
        return "redirect:/login";
    }

    // 🔥 LOGOUT
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); // remove session
        return "redirect:/login";
    }
}
